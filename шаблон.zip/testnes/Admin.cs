﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testnes
{
    public partial class Admin : Form
    {
        private FormLogin _formLog;
        public Admin(FormLogin formLog)
        {
            InitializeComponent();
            _formLog = formLog;
            LoadUsers();
        }

        private void LoadUsers()
        {
            listViewUsers.Items.Clear();
            foreach (var user in UserCred.Users)
            {
                if (!string.IsNullOrEmpty(user.Login) && !string.IsNullOrEmpty(user.Pass))
                {
                    var item = new ListViewItem(user.Login);
                    item.SubItems.Add(user.Pass);
                    listViewUsers.Items.Add(item);
                }
            }
        }

    }
}
