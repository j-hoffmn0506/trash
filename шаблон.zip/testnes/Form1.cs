﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testnes
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обрабатывает текст боксы и вызывает формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLog_Click(object sender, EventArgs e)
        {
            //Любое из полей пустое
            if (string.IsNullOrWhiteSpace(txtLog.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Поля не могут быть пустыми!");
            }

            //Введены данные Админа
            if (txtLog.Text == UserCred.AdminLogin && txtPass.Text == UserCred.AdminPass)
            {
                MessageBox.Show("Вы вошли как Админ!");
                Admin admin = new Admin(this);
                admin.FormClosed += (s, args) =>
                {
                    this.Show();
                    txtLog.Clear();
                    txtPass.Clear();
                };
                UserCred.Guest = false;
                this.Hide();
                admin.Show();

            }

            else if (UserCred.Users.Exists(u => u.Login == txtLog.Text && u.Pass == txtPass.Text))
            {
                MessageBox.Show("Вы вошли в систему!");
                UserUI userUI = new UserUI(this);
                userUI.FormClosed += (s, args) =>
                {
                    this.Show();
                    txtLog.Clear();
                    txtPass.Clear();
                };
                UserCred.Guest = false;
                this.Hide();
                userUI.Show();
            }

            else
            {
                MessageBox.Show("Неверный логин или пароль!");
            }
        }

        /// <summary>
        /// Отправляет на страницу регистрации
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReg_Click(object sender, EventArgs e)
        {
            FormReg reg = new FormReg(this);
            reg.FormClosed += (s, args) =>
            {
                this.Show();
                txtLog.Clear();
                txtPass.Clear();
            };
            this.Hide();
            reg.Show();
            
        }

        /// <summary>
        /// Вход от лица Гостя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuest_Click(object sender, EventArgs e)
        {
            UserUI userUI = new UserUI(this);
            userUI.FormClosed += (s, args) =>
            {
                this.Show();
                UserCred.Guest = false;
                txtLog.Clear();
                txtPass.Clear();
            };UserCred.Guest = true;
            this.Hide();
            userUI.Show();
            CurrentUser.CurrLogin = null;
            CurrentUser.CurrPass = null;
            
            MessageBox.Show($"Вы вошли как гость! \n{UserCred.Guest}");
        }
    }
}
