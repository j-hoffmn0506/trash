﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testnes
{
    public partial class FormReg : Form
    {
        private FormLogin _formLog;
        public FormReg(FormLogin formLog)
        {
            _formLog = formLog;
            InitializeComponent();
        }

        /// <summary>
        /// Обрабатывает текстбоксы и записывает пользователя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReg_Click(object sender, EventArgs e)
        {
            //Любое из полей пустое
            if (string.IsNullOrWhiteSpace(txtRegLog.Text) || string.IsNullOrWhiteSpace(txtRegPass1.Text))
            {
                MessageBox.Show("Поля не должны быть пустыми!", "Ошибка");
                return;
            }

            //Пароли не совпадают
            if (txtRegPass1.Text != txtRegPass2.Text) 
            {
                MessageBox.Show("Пароли не совпадают!", "Ошибка");
                return;
            }
            if (UserCred.Users.Exists(u => u.Login == txtRegLog.Text))
            {
                MessageBox.Show("Такой пользователь уже существует!", "Ошибка");
                return;
            }
            UserCred.Users.Add((txtRegLog.Text, txtRegPass1.Text));
            MessageBox.Show("Регистрация прошла успешно!");
            _formLog.Show();
            this.Close();

        }

        /// <summary>
        /// Выход из окна регистрации
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnC_Click(object sender, EventArgs e)
        {
            _formLog.Show();
            this.Close();
        }
    }
}
