﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testnes
{
    /// <summary>
    /// Содержит пользователей
    /// (Без БД можно записать только ограниченное число новых пользователей)
    /// </summary>
    public static class UserCred
    {
        public static List<(string Login, string Pass)> Users { get; set; } = new List<(string Login, string Pass)>
        {
            ("User", "user") //Предустановленный пользователь
        };
        //Флаг гостя
        public static bool Guest {get; set;}

        //Админ
        public static readonly string AdminLogin = "Admin";

        public static readonly string AdminPass = "admin";

    }
    /// <summary>
    /// Текущий юзер для UserUI
    /// </summary>
    public static class CurrentUser
    {
        public static string CurrLogin;
        public static string CurrPass;
    }

    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormLogin());
        }
    }
}
