﻿namespace testnes
{
    partial class UserUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuest = new System.Windows.Forms.Button();
            this.btnNonGuest = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGuest
            // 
            this.btnGuest.Location = new System.Drawing.Point(247, 212);
            this.btnGuest.Name = "btnGuest";
            this.btnGuest.Size = new System.Drawing.Size(179, 23);
            this.btnGuest.TabIndex = 0;
            this.btnGuest.Text = "Кнопка для гостя";
            this.btnGuest.UseVisualStyleBackColor = true;
            // 
            // btnNonGuest
            // 
            this.btnNonGuest.Location = new System.Drawing.Point(247, 242);
            this.btnNonGuest.Name = "btnNonGuest";
            this.btnNonGuest.Size = new System.Drawing.Size(179, 23);
            this.btnNonGuest.TabIndex = 1;
            this.btnNonGuest.Text = "Кнопка не для гостя";
            this.btnNonGuest.UseVisualStyleBackColor = true;
            // 
            // UserUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 450);
            this.Controls.Add(this.btnNonGuest);
            this.Controls.Add(this.btnGuest);
            this.Name = "UserUI";
            this.Text = "UserUI";
            this.Load += new System.EventHandler(this.UserUI_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGuest;
        private System.Windows.Forms.Button btnNonGuest;
    }
}